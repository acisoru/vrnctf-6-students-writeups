extern crate core;

use std::fs::File;
use std::io::{Read, Write};
use std::num::Wrapping;
use std::path::Path;
use std::rc::Rc;
use rand::Rng;

const NUMBER_OF_LOGS: u32 = 6;

#[derive(Clone, Debug, Copy)]
struct RNG {
    state: [Wrapping<u32>; 5],
    counter: Wrapping<u32>,
}

impl RNG {
    fn new() -> Self {
        let mut rng = rand::thread_rng();
        let mut states: [Wrapping<u32>; 5] = [
            Wrapping(0),
            Wrapping(0),
            Wrapping(0),
            Wrapping(0),
            Wrapping(0)
        ];
        rng.fill(&mut states);
        let prng = Self {
            state: states,
            counter: Wrapping(0),
        };
        prng
    }
    fn next(&mut self) -> u32 {
        let mut t = self.state[4];
        let s = self.state[0];
        self.state[4] = self.state[3];
        self.state[3] = self.state[2];
        self.state[2] = self.state[1];
        self.state[1] = s;
        t ^= t >> 2;
        t ^= t << 1;
        t ^= s ^ (s << 4);
        self.state[0] = t;
        self.counter += Wrapping(362437);
        return (t + self.counter).0;
    }
}

union Convertable<'a> {
    eights: &'a [u8],
    thirty_twos: &'a [u32],
    sixty_four: &'a u64,
}

fn eights_to_sixty_four(eights: &[u8]) -> &u64 {
    let convertable = Convertable {
        eights: &eights
    };
    unsafe {
        return convertable.sixty_four;
    }
}

fn thirty_twos_to_sixty_four(thirty_twos: &[u32]) -> &u64 {
    let convertable = Convertable {
        thirty_twos: &thirty_twos
    };
    unsafe {
        return convertable.sixty_four;
    }
}

fn encrypt(input: &str, prng: &mut Rc<RNG>) -> (Vec<u64>, Vec<String>) {
    let mut chunks_vec: Vec<u64> = vec![];
    let rng = Rc::get_mut(prng).unwrap();
    let v: Vec<u8> = input.bytes().collect();
    let chunks = v.chunks(8);
    let mut words = vec![];
    let mut counter = 0;
    for chunk in chunks {
        let sixty_four = eights_to_sixty_four(chunk);
        let first = rng.next();
        if counter < NUMBER_OF_LOGS {
            words.push(format!("Перун молвит: {first}"));
            counter += 1;
        }
        let second = rng.next();
        if counter < NUMBER_OF_LOGS {
            words.push(format!("Перун молвит: {second}"));
            counter += 1;
        }
        let block = &[first, second];
        let sf_random = thirty_twos_to_sixty_four(block);
        chunks_vec.push(sf_random ^ sixty_four);
    }
    return (chunks_vec, words);
}

fn write_blocks_to_file(input: Vec<u64>) {
    let path = Path::new("res/encrypted.bin");
    let mut output = File::create(path).unwrap();
    for quad_word in input.iter() {
        println!("{}", quad_word);
        let bytes: [u8; 8] = quad_word.to_le_bytes();
        output.write(&bytes).expect("Не удалось записать байты в файл encrypted.bin");
    }
}

fn vec_to_str(input: Vec<String>) -> String {
    let mut output = String::new();
    for element in input {
        output += &*element.to_string();
        output += "\n";
    }
    output.remove(output.len() - 1);
    output
}

fn write_to_file(input: String, path_url: &str) {
    let mut output = File::create(path_url).unwrap();
    write!(output, "{}", input).unwrap();
}

fn get_from_file(path_url: &str) -> &str {
    let path = Path::new(&path_url);
    let mut file = match File::open(&path) {
        Ok(f) => f,
        Err(err) => panic!("Ошибка, связанная с чтением из файла: {}", err)
    };
    let mut str: String = String::new();
    file.read_to_string(&mut str).unwrap();
    return str.leak();
}

fn main() {
    let rng = &mut Rc::new(RNG::new());
    let input_text = get_from_file("res/input.txt");
    let (encrypted_blocks, words) = encrypt(input_text, rng);
    write_blocks_to_file(encrypted_blocks);
    let words_str = vec_to_str(words);
    write_to_file(words_str, "res/words.txt");
}
